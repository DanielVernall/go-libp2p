package main

import (
	"context"
	"log"

	"github.com/libp2p/go-libp2p"
	"github.com/libp2p/go-libp2p/core/host"
	"github.com/libp2p/go-libp2p/core/peer"
)

func New() (host.Host, error) {
	//Google Cloud VM relay @ 34.72.182.121
	knownPeerInfo, err := peer.AddrInfoFromString("/ip4/34.72.182.121/udp/4001/quic/p2p/12D3KooWJLAnFgN66ixvtjDfro5YifLkCnGXNE6ritcKJHR1NX32")
	if err != nil {
		return nil, err
	}

	// Create a host that will attempt NAT Traversal automatically
	h, err := libp2p.New(
		libp2p.NATPortMap(),
		libp2p.EnableAutoRelay(),
		libp2p.StaticRelays([]peer.AddrInfo{
			*knownPeerInfo,
		}),
	)
	if err != nil {
		return nil, err
	}

	log.Printf("Initial listen addresses: %v", h.Addrs())

	if err := h.Connect(context.Background(), *knownPeerInfo); err != nil {
		log.Printf("Could not connect to known peer: %v", err)
	}

	log.Printf("Connected to known peer")
	log.Printf("Updated listen addresses: %v", h.Addrs())

	return h, nil
}

func main() {
	_, err := New()
	if err != nil {
		log.Printf("Error creating host %v", err)
	}

	select {} // Wait forever
}
