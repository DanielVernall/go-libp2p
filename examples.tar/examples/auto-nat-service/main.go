package main

import (
	"log"

	"github.com/libp2p/go-libp2p"
)

func main() {
	run()
}

func run() {
	addrs := []string{
		"/ip4/0.0.0.0/udp/4001/quic",
		"/ip6/::/udp/4001/quic",
		"/ip4/0.0.0.0/tcp/4001",
		"/ip6/::/tcp/4001",
	}

	h, err := libp2p.New(
		libp2p.EnableNATService(),
		libp2p.EnableRelayService(),
		libp2p.ListenAddrStrings(addrs...),
	)

	if err != nil {
		log.Panicf("Error creating host: %v", err)
	}

	log.Printf("Started listening on: %v", h.Addrs())
	log.Printf("Relay service running...")
	log.Printf("NAT service running...")
}
