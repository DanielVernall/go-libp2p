# 05 Discovery

Be sure to check out these modules:

- https://godoc.org/github.com/libp2p/go-libp2p#Routing
- https://godoc.org/github.com/libp2p/go-libp2p-kad-dht#New
